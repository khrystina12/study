printf("Array:\n");
    for (i = 0; i<N; i++) {
        printf("%i ", A[i]);
    }
    printf("\n");